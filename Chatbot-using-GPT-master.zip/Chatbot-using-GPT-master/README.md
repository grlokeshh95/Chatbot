# Chatbot-using-GPT
The emerging trend shows that the people interest and interaction with chatbot
grows steadily. In most of the homes, people use voice assistants like Siri, Alexa and
Hey Google. There is another very important trend which shows that the people
are interested in using messaging applications compared to other applications in mo
bile which is evident from the growth of messaging applications into a major market
like WhatsApp, Messenger and Viber. There is little research going on for building
the chatbots which are not based on speciﬁc goals but to act as companion. In this
project, the chatbot is created not based on any speciﬁc domains. This is a diﬃcult
task compared to building customer support chatbots. In customer support, the chat
bots can be created by framing relevant questions and responses. The challenge for
the non – goal oriented chatbot is to mimic human conversations to engage the users.
The recent advancements in NLP like sequence to sequence model (RNN) and Trans
former(Attention mechanism) improve the task of machine translation and language
modeling in a large scale. In our work, we have used transformer as an underlying
architecture for the chatbot to improve experience of the users. In this project, Users
can choose the options among voice and text for the interacting with the chatbot.
